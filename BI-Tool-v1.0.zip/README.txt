BI Tool - Local Version
=======================

[Start]
Double-click "start.bat"
-> Browser opens http://localhost:8080

[Stop]
Close the black window
